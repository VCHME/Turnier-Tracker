// app v134
console.log('Turnier-Tracker v1.3.4 geladen');
// Verteilung der Spiele auf zwei Courts – gleichmäßig simulieren
